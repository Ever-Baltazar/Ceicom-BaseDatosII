/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

/**
 *
 * @author Tp-Link
 */
public class Ventana extends javax.swing.JFrame {

    /**
     * Creates new form Ventana
     */
    public Ventana()
    {       
        initComponents();
        jTabbedPanelCli.setVisible(false);
        //panelRegistroEst1.setVisible(false);
        //panelRegistroDoc1.setVisible(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToolBar1 = new javax.swing.JToolBar();
        jButtonPrincipal = new javax.swing.JButton();
        jButtonEstudiante = new javax.swing.JButton();
        jButtonDocente = new javax.swing.JButton();
        jButtonMateria = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        panelPrincipal1 = new ventanas.PanelPrincipal();
        jTabbedPanelCli = new javax.swing.JTabbedPane();
        panelRegistroCli1 = new ventanas.PanelRegistroCli();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jToolBar1.setRollover(true);

        jButtonPrincipal.setText("Principal");
        jButtonPrincipal.setFocusable(false);
        jButtonPrincipal.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonPrincipal.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonPrincipal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPrincipalActionPerformed(evt);
            }
        });
        jToolBar1.add(jButtonPrincipal);

        jButtonEstudiante.setText("Cliente");
        jButtonEstudiante.setFocusable(false);
        jButtonEstudiante.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonEstudiante.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonEstudiante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEstudianteActionPerformed(evt);
            }
        });
        jToolBar1.add(jButtonEstudiante);

        jButtonDocente.setText("Docente");
        jButtonDocente.setFocusable(false);
        jButtonDocente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonDocente.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonDocente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDocenteActionPerformed(evt);
            }
        });
        jToolBar1.add(jButtonDocente);

        jButtonMateria.setText("Materia");
        jButtonMateria.setFocusable(false);
        jButtonMateria.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonMateria.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar1.add(jButtonMateria);

        jButton5.setText("jButton5");
        jButton5.setFocusable(false);
        jButton5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar1.add(jButton5);

        getContentPane().add(jToolBar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 520, 30));
        getContentPane().add(panelPrincipal1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 530, 340));

        jTabbedPanelCli.addTab("tab1", panelRegistroCli1);

        getContentPane().add(jTabbedPanelCli, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 530, 340));

        jMenu1.setText("Archivo");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Ayuda");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonPrincipalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPrincipalActionPerformed
        //panelRegistroEst1.setVisible(false);
        //panelRegistroDoc1.setVisible(false);
        jTabbedPanelCli.setVisible(false);
        panelPrincipal1.setVisible(true);
    }//GEN-LAST:event_jButtonPrincipalActionPerformed

    private void jButtonEstudianteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEstudianteActionPerformed
        panelPrincipal1.setVisible(false);
        jTabbedPanelCli.setVisible(true);
        //panelRegistroDoc1.setVisible(false);
        //panelRegistroEst1.setVisible(true);
        
    }//GEN-LAST:event_jButtonEstudianteActionPerformed

    private void jButtonDocenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDocenteActionPerformed
        panelPrincipal1.setVisible(false);
        //panelRegistroEst1.setVisible(false);
        //panelRegistroDoc1.setVisible(true);
    }//GEN-LAST:event_jButtonDocenteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ventana().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButtonDocente;
    private javax.swing.JButton jButtonEstudiante;
    private javax.swing.JButton jButtonMateria;
    private javax.swing.JButton jButtonPrincipal;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JTabbedPane jTabbedPanelCli;
    private javax.swing.JToolBar jToolBar1;
    private ventanas.PanelPrincipal panelPrincipal1;
    private ventanas.PanelRegistroCli panelRegistroCli1;
    // End of variables declaration//GEN-END:variables
}
